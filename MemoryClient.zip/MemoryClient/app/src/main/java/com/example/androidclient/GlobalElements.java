package com.example.androidclient;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;

public class GlobalElements {
    private static Socket socket;
    private static BufferedReader br;
    private static PrintWriter pw;

    public static synchronized Socket getSocket(){
        return socket;
    }

    public static synchronized BufferedReader getBufferedReader(){
        return br;
    }

    public static synchronized PrintWriter getPrintWriter(){
        return pw;
    }

    public static synchronized void setSocket(Socket socket){
        GlobalElements.socket = socket;
    }

    public static synchronized void setBufferedReader(BufferedReader br){
        GlobalElements.br = br;
    }

    public static synchronized void setPrintWriter(PrintWriter pw){
        GlobalElements.pw = pw;
    }
}
