package com.example.androidclient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import static java.util.Collections.shuffle;

public class GameActivity extends AppCompatActivity {

    String userName;
    Thread threadReceive = null;
    boolean myTurn = false;
    String key;
    ArrayList<Integer> cards;
    // 0 - okrenuta, 1 - trenutno otkrivena, 2 - stalno otkrivena
    ArrayList<Integer> cardStatus;
    String result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.REQUEST_MESSAGE);
        this.userName = message.split(":")[0];
        if(message.split(":")[1].equals("true")) {
            this.myTurn = true;
        }
        this.key = message.split(":")[2];

        this.threadReceive = new Thread(new ReceiveMessageFromServer());
        this.threadReceive.start();
        this.cards = new ArrayList();
        this.cardStatus = new ArrayList();
        for(int i = 0; i < 30; i++)
            this.cardStatus.add(0);

        if(this.myTurn)
        {
            for(int i = 0; i < 30; i++)
                this.cards.add(i % 15);
            shuffle(this.cards);

            String tempMessage = "sendInitSate:";
            tempMessage += this.getReceiver() + ":";
            for(Integer el : this.cards)
            {
                tempMessage += el + ",";
            }
            tempMessage = tempMessage.substring(0, tempMessage.length() - 1);
            final String serverMessage = tempMessage;
            new Thread(new Runnable(){
                @Override
                public void run()
                {
                    GlobalElements.getPrintWriter().println(serverMessage);
                }
            }).start();

        }


    }

    class ReceiveMessageFromServer implements Runnable {
        @Override
        public void run() {
            while (true) {
                String line;
                try {
                    line = GlobalElements.getBufferedReader().readLine();

                    if(line.startsWith("receiveInitState:"))
                    {
                        String[] cardsData = line.split(":")[1].split("[,]");
                        for(int i = 0; i < 30; i++)
                            GameActivity.this.cards.add(Integer.parseInt(cardsData[i]));
                    }
                    else if(line.startsWith("receiveInitState:"))
                    {
                        // instruction:cardsStatus:turn
                        GameActivity.this.cards.removeAll(GameActivity.this.cards);
                        String[] cardsData = line.split(":")[1].split("[,]");
                        for(int i = 0; i < 30; i++)
                            GameActivity.this.cards.add(Integer.parseInt(cardsData[i]));
                        if(line.split(":")[2].equals("true"))
                            GameActivity.this.myTurn = true;
                        else
                            GameActivity.this.myTurn = false;
                    }

                } catch (IOException ex) {
                    Logger.getLogger(MainActivity.ReceiveMessageFromServer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public String getReceiver()
    {
        if(this.key.split("[$]]")[0].equals(this.userName))
            return this.key.split("[$]]")[1];
        else
            return this.key.split("[$]]")[0];
    }

    public void sendMessage(String turn)
    {
        String tempMsg = "sendCurrentState:";
        tempMsg += this.getReceiver() + ":";
        for(Integer el : this.cardStatus)
            tempMsg += el + ",";
        tempMsg = tempMsg.substring(0, tempMsg.length() - 1) + ":" + turn;
        final String serverMsg = tempMsg;
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println(serverMsg);
            }
        }).start();

    }
}