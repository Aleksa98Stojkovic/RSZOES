package com.example.androidclient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import static java.util.Collections.shuffle;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.Date;

public class GameActivity extends AppCompatActivity {

    /* Activity switch variables */
    public static final String RESPONSE_MESSAGE = "END_GAME";
    Intent intent;


    /* GUI */
    Button btnDecline;
    Button btnAccept;
    Button btnStartNewGame;
    TextView tvInfo;
    int numRows = 6;
    int numColumns = 5;
    HashMap<Integer, ImageView> images;
    HashMap<Integer, String> imageNames;
    int positionFirstSelected;
    /* ************************************* */

    String userName;
    Thread threadReceive = null;
    boolean myTurn = false;
    String key;
    ArrayList<Integer> cards;
    // 0 - okrenuta, 1 - trenutno otkrivena, 2 - stalno otkrivena
    ArrayList<Integer> cardStatus;
    int myResult;
    int opponentsResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        this.positionFirstSelected = -1;

        /* GUI */
        this.btnDecline = findViewById(R.id.btnDecline);
        this.btnDecline.setOnClickListener(v -> GameActivity.this.declineNewGame());
        this.btnAccept = findViewById(R.id.btnAccept);
        this.btnAccept.setOnClickListener(v -> GameActivity.this.acceptNewGame());
        this.btnStartNewGame = findViewById(R.id.btnSendRequest);
        this.btnStartNewGame.setOnClickListener(v -> GameActivity.this.askForNewGame());
        this.tvInfo = findViewById(R.id.tvMessage);
        this.images = new HashMap<>();
        this.imageNames = new HashMap<>();
        this.initImageNames();
        LinearLayout llmain = findViewById(R.id.lvmain);

        for (int row = 1; row <= numRows; row++){
            LinearLayout llrow = new LinearLayout(this);
            llrow.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 1; col <= numColumns; col++){
                ImageView iv = new ImageView(this);
                iv.setTag((row - 1) * 5 + col - 1);
                images.put((row - 1) * 5 + col - 1, iv);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0,200);
                layoutParams.weight = 1;
                iv.setLayoutParams(layoutParams);
                iv.setImageResource(R.drawable.background);
                llrow.addView(iv);

                iv.setOnClickListener((v)->{

                    int position = (int)v.getTag();
                    // Treba proveriti da nije kliknuta vec otvorena karta
                    if((position != this.positionFirstSelected) && (this.cardStatus.get(position) != 2))
                    {
                        if(this.myTurn)
                        {
                            // Da li je ovo prvi pokusaj ili drugi?
                            // Drugi pokusaj
                            if (this.positionFirstSelected != -1)
                            {
                                // Desio se pogodak
                                if(this.cards.get(position) == this.cards.get(this.positionFirstSelected))
                                {
                                    // Treba proveriti da li je zbir dva rezultata 15
                                    this.myResult++;
                                    this.tvInfo.setText("Rezultat: Ja = " + this.myResult + ", " + "Protivnik = " + this.opponentsResult);
                                    this.cardStatus.set(position, 2);
                                    this.sendMessage("false", position, 2);
                                    this.cardStatus.set(this.positionFirstSelected, 2);
                                    this.sendMessage("false", this.positionFirstSelected, 2);
                                    this.positionFirstSelected = -1;
                                    this.checkGameState();
                                }
                                // Desio se promasaj
                                else
                                {
                                    int imageID = this.cards.get(position);
                                    String imageName = this.imageNames.get(imageID);
                                    int drawableResourceId = this.getResources().getIdentifier(imageName, "drawable", this.getPackageName());
                                    iv.setImageResource(drawableResourceId);
                                    this.cardStatus.set(position, 1);
                                    this.sendMessage("false", position, 1);

                                    // Kasnjenje
                                    // DEBUG kasnjenje
                                    for(long i = 0; i < 1000000; i++)
                                    {
                                        // System.out.println("Stani");
                                    }
                                    /*
                                    try {
                                        TimeUnit.MILLISECONDS.sleep(1000);
                                    }
                                    catch(InterruptedException ex) {
                                        ex.printStackTrace();
                                    }
                                    */

                                    this.cardStatus.set(position, 0);
                                    this.sendMessage("false", position, 0);
                                    this.cardStatus.set(this.positionFirstSelected, 0);
                                    this.sendMessage("true", this.positionFirstSelected, 0);
                                    iv.setImageResource(R.drawable.background);
                                    images.get(this.positionFirstSelected).setImageResource(R.drawable.background);
                                    this.positionFirstSelected = -1;
                                    this.myTurn = false;

                                }
                            }
                            // Prvi pokusaj
                            else
                            {
                                this.positionFirstSelected = position;
                                int imageID = this.cards.get(position);
                                String imageName = this.imageNames.get(imageID);
                                int drawableResourceId = this.getResources().getIdentifier(imageName, "drawable", this.getPackageName());
                                iv.setImageResource(drawableResourceId);
                                this.cardStatus.set(position, 1);
                                this.sendMessage("false", position, 1);
                            }
                        }
                        else
                        {
                            // Treba ispisati tekst na TextView da igrac nije na redu
                        }
                    }
                });
            }
            llmain.addView(llrow);
        }

        /* ************************************* */

        this.myResult = 0;
        this.opponentsResult = 0;
        this.tvInfo.setText("Rezultat: Ja = " + this.myResult + ", " + "Protivnik = " + this.opponentsResult);
        this.intent = getIntent();
        String message = intent.getExtras().getString(MainActivity.REQUEST_MESSAGE);
        this.userName = message.split(":")[0];
        if(message.split(":")[1].equals("true")) {
            this.myTurn = true;
        }
        this.key = message.split(":")[2];

        this.threadReceive = new Thread(new ReceiveMessageFromServer());
        this.threadReceive.start();
        this.cards = new ArrayList();
        this.cardStatus = new ArrayList();
        for(int i = 0; i < 30; i++)
            this.cardStatus.add(0);

        if(this.myTurn)
        {
            for(int i = 0; i < 30; i++)
                this.cards.add(i % 15);

            shuffle(this.cards);

            String tempMessage = "sendInitSate:";
            tempMessage += this.getReceiver() + ":";
            for(Integer el : this.cards)
            {
                tempMessage += el + ",";
            }
            tempMessage = tempMessage.substring(0, tempMessage.length() - 1);
            final String serverMessage = tempMessage;
            new Thread(new Runnable(){
                @Override
                public void run()
                {
                    GlobalElements.getPrintWriter().println(serverMessage);
                    System.out.println(GameActivity.this.userName + ":Prvi posiljalac");
                }
            }).start();

        }
    }

    class ReceiveMessageFromServer implements Runnable {
        @Override
        public void run() {
            while (true) {
                String line;
                try {

                    line = GlobalElements.getBufferedReader().readLine();
                    System.out.println(GameActivity.this.userName + "||" + line);

                    if(line.startsWith("receiveInitState:"))
                    {
                        String[] cardsData = line.split(":")[1].split("[,]");
                        for(int i = 0; i < 30; i++)
                            GameActivity.this.cards.add(Integer.parseInt(cardsData[i]));
                    }
                    else if(line.startsWith("receiveCurrentState:"))
                    {
                        // instruction:position,value:turn:result
                        int index = Integer.parseInt(line.split(":")[1].split("[,]")[0]);
                        int value = Integer.parseInt(line.split(":")[1].split("[,]")[1]);
                        GameActivity.this.cardStatus.set(index, value);
                        if(line.split(":")[2].equals("true"))
                            GameActivity.this.myTurn = true;
                        else
                            GameActivity.this.myTurn = false;

                        GameActivity.this.opponentsResult = Integer.parseInt(line.split(":")[3]);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // GameActivity.this.updateCardsOnGUI();

                                GameActivity.this.tvInfo.setText("Rezultat: Ja = " + GameActivity.this.myResult + ", " + "Protivnik = " + GameActivity.this.opponentsResult);
                                GameActivity.this.checkGameState();
                                for(int i = 0; i < GameActivity.this.cardStatus.size(); i++)
                                {
                                    if(GameActivity.this.cardStatus.get(i) == 0)
                                    {
                                        GameActivity.this.images.get(i).setImageResource(R.drawable.background);
                                    }
                                    else if(GameActivity.this.cardStatus.get(i) == 1)
                                    {
                                        int imageID = GameActivity.this.cards.get(i);
                                        String imageName = GameActivity.this.imageNames.get(imageID);
                                        int drawableResourceId = GameActivity.this.getResources().getIdentifier(imageName, "drawable", GameActivity.this.getPackageName());
                                        GameActivity.this.images.get(i).setImageResource(drawableResourceId);
                                    }
                                }
                            }
                        });
                    }
                    else if(line.startsWith("receiveTextMessage:"))
                    {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                GameActivity.this.tvInfo.setText(line.split(":")[1]);
                            }
                        });

                        if(line.contains("prihvatio"))
                        {
                            GameActivity.this.myTurn = true;
                        }
                    }
                    else if(line.startsWith("receiveEndActivity:"))
                    {
                        setResult(RESULT_OK, GameActivity.this.intent);
                        finish();
                    }

                } catch (IOException ex) {
                    Logger.getLogger(MainActivity.ReceiveMessageFromServer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public String getReceiver()
    {
        String res;
        if(this.key.split("[$]")[0].equals(this.userName))
            res = this.key.split("[$]")[1];
        else
            res = this.key.split("[$]")[0];

        return res;
    }

    public void sendMessage(String turn, int position, int value)
    {
        String tempMsg = "sendCurrentState:";
        tempMsg += this.getReceiver() + ":";
        tempMsg += position + "," + value + ":" + turn + ":" + this.myResult;
        final String serverMsg = tempMsg;
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println(serverMsg);
                System.out.println(GameActivity.this.userName + ":Drugi posiljalac");
            }
        }).start();

    }

    public void initImageNames()
    {
        this.imageNames.put(0, "apple");
        this.imageNames.put(1, "intel");
        this.imageNames.put(2, "amd");
        this.imageNames.put(3, "mercedes");
        this.imageNames.put(4, "porsche");
        this.imageNames.put(5, "rpi");
        this.imageNames.put(6, "arm");
        this.imageNames.put(7, "bosch");
        this.imageNames.put(8, "siemens");
        this.imageNames.put(9, "google");
        this.imageNames.put(10, "infineon");
        this.imageNames.put(11, "nxp");
        this.imageNames.put(12, "tesla");
        this.imageNames.put(13, "tsmc");
        this.imageNames.put(14, "nvidia");
        this.imageNames.put(15, "background");
    }

    public void checkGameState()
    {
        // Igra je zavrsena
        if(this.myResult + this.opponentsResult == 15)
        {
            if(this.myResult > this.opponentsResult)
                this.tvInfo.setText("Pobedili ste!");
            else
                this.tvInfo.setText("Izgubili ste!");

            this.myResult = 0;
            this.opponentsResult = 0;
            this.myTurn = false;
            this.cardStatus.removeAll(this.cardStatus);
            for(int i = 0; i < 30; i++)
                this.cardStatus.add(0);
            this.cards.removeAll(this.cards);
        }
    }

    public void askForNewGame()
    {
        for(int i = 0; i < 30; i++)
            this.cards.add(i % 15);

        shuffle(this.cards);

        String tempMessage = "sendInitSate:";
        tempMessage += this.getReceiver() + ":";
        for(Integer el : this.cards)
        {
            tempMessage += el + ",";
        }
        tempMessage = tempMessage.substring(0, tempMessage.length() - 1);
        final String serverMessage = tempMessage;
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println(serverMessage);
                System.out.println(GameActivity.this.userName + ":Prvi posiljalac");
                GlobalElements.getPrintWriter().println("sendTextMessage:" + GameActivity.this.getReceiver() + ":Korinsik " + GameActivity.this.userName + " želi ponovo da igra sa Vama");
            }
        }).start();
    }

    public void acceptNewGame()
    {
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println("sendTextMessage:" + GameActivity.this.getReceiver() + ":Korinsik " + GameActivity.this.userName + " je prihvatio novu igru");
            }
        }).start();
    }

    public void declineNewGame()
    {
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println("sendEndActivity:" + GameActivity.this.getReceiver() + ":" + GameActivity.this.key);
            }
        }).start();
        setResult(RESULT_OK, intent);
        finish();
    }

    /*
    public void updateCardsOnGUI()
    {
        for(int i = 0; i < this.cardStatus.size(); i++)
        {
            if(this.cardStatus.get(i) == 0)
            {
                this.images.get(i).setImageResource(R.drawable.background);
            }
            else if(this.cardStatus.get(i) == 1)
            {
                int imageID = this.cards.get(i);
                String imageName = this.imageNames.get(imageID);
                int drawableResourceId = this.getResources().getIdentifier(imageName, "drawable", this.getPackageName());
                this.images.get(i).setImageResource(drawableResourceId);
            }
        }
    }
    */
}