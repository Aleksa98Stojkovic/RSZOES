package com.example.androidclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ReceiveMessageFromServer implements Runnable{

    BufferedReader br;
    MainActivity parent;

    public ReceiveMessageFromServer(MainActivity parent)
    {
        this.parent = parent;
        this.br = this.parent.getBr();
    }

    @Override
    public void run()
    {
        while (true) {
            String line;
            try {

                line = this.br.readLine();
                if(line.startsWith("Spinner"))
                {
                    String msg = line.split(":")[1];
                    if(msg.contains(",")) {
                        String[] users = msg.split(",");
                        this.parent.setSpinner(users);
                    }
                    else {
                        String[] user = new String[1];
                        user[0] = msg;
                        this.parent.setSpinner(user);
                    }
                }

            } catch (IOException ex) {
                Logger.getLogger(ReceiveMessageFromServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
