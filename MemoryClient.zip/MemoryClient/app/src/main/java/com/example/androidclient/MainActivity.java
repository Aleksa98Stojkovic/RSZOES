package com.example.androidclient;

import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.net.Socket;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Thread Thread1 = null;
    Thread threadReceive = null;
    String SERVER_IP;
    String userName;
    int SERVER_PORT = 8080;

    // GUI elements
    Button btnRegister;
    Button btnAccept;
    Button btnDecline;
    Button btnSend;
    EditText etUserName;
    EditText etIP;
    TextView tvInfo;
    Spinner spUsers;

    // Needed for connection with another activity
    public static final String REQUEST_MESSAGE = "START_GAME";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.btnRegister = findViewById(R.id.btnRegistruj);
        this.btnAccept = findViewById(R.id.btnPrihvati);
        this.btnDecline = findViewById(R.id.btnOdbij);
        this.btnSend = findViewById(R.id.btnPošalji);
        this.etUserName = findViewById(R.id.etIme);
        this.etIP = findViewById(R.id.etIP);
        this.tvInfo = findViewById(R.id.tvInfo);
        this.spUsers = findViewById(R.id.spKorisnici);

        // Attaching functions to buttons
        this.btnRegister.setOnClickListener(v -> MainActivity.this.registerUser());
        this.btnAccept.setOnClickListener(v -> MainActivity.this.acceptGame());
        this.btnDecline.setOnClickListener(v -> MainActivity.this.declineGame());
        this.btnSend.setOnClickListener(v -> MainActivity.this.sendGameRequest());
    }

    public BufferedReader getBr()
    {
        return GlobalElements.getBufferedReader();
    }

    private void registerUser()
    {
        this.SERVER_IP = this.etIP.getText().toString();
        this.userName = this.etUserName.getText().toString();
        if(!this.userName.equals("")) {
            Thread1 = new Thread(new ConnectWithServer());
            Thread1.start();
        }
    }

    class ConnectWithServer implements Runnable {
        @Override
        public void run() {
            try {
                GlobalElements.setSocket(new Socket(SERVER_IP, SERVER_PORT));
                GlobalElements.setPrintWriter(new PrintWriter(GlobalElements.getSocket().getOutputStream(), true));
                GlobalElements.setBufferedReader(new BufferedReader(new InputStreamReader(GlobalElements.getSocket().getInputStream())));
                threadReceive = new Thread(new ReceiveMessageFromServer());
                threadReceive.start();
                String msg = "init:" + userName;
                GlobalElements.getPrintWriter().println(msg);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class ReceiveMessageFromServer implements Runnable {
        @Override
        public void run() {
            while (true) {
                String line;
                try {
                    line = GlobalElements.getBufferedReader().readLine();

                    if (line.startsWith("Spinner")) {
                        String msg = line.split(":")[1];
                        if (msg.contains(",")) {
                            String[] users = msg.split(",");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    MainActivity.this.setSpinner(users);
                                }
                            });

                        } else {
                            String[] user = new String[1];
                            user[0] = msg;
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    MainActivity.this.setSpinner(user);
                                }
                            });
                        }
                    }
                    else if(line.startsWith("gameRequest") || line.startsWith("declineServer")) {
                        String message = GlobalElements.getBufferedReader().readLine();
                        System.out.println(message);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                MainActivity.this.tvInfo.setText(message.split(":")[1]);
                            }
                        });
                    }
                    else if(line.startsWith("acceptServer")) {
                        // Startujemo novu aktivnost
                        Intent intent = new Intent(MainActivity.this, GameActivity.class);
                        String key = MainActivity.this.userName + "$" + line.split(":")[1];
                        String message = MainActivity.this.userName + ":" + "true" + ":" + key;
                        intent.putExtra(MainActivity.REQUEST_MESSAGE, message);
                        startActivity(intent);
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ReceiveMessageFromServer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    private void acceptGame()
    {
        String user = this.spUsers.getSelectedItem().toString();
        final String message = "acceptClient:" + user;
        Intent intent = new Intent(this, GameActivity.class);
        String key = user + "$" + this.userName;
        String msg = this.userName + ":" + "false" + ":" + key;
        intent.putExtra(REQUEST_MESSAGE, msg);
        startActivity(intent);
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println(message);
            }
        }).start();
    }

    private void declineGame()
    {
        String user = this.spUsers.getSelectedItem().toString();
        String message = "declineClient:" + user;
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println(message);
            }
        }).start();
    }

    private void sendGameRequest()
    {
        String user = this.spUsers.getSelectedItem().toString();
        String message = "sendRequest:" + user;
        new Thread(new Runnable(){
            @Override
            public void run()
            {
                GlobalElements.getPrintWriter().println(message);
            }
        }).start();
    }

    public void setSpinner(String[] users)
    {
        if(!users[0].equals("None")) {
            ArrayAdapter ad
                    = new ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    users);

            ad.setDropDownViewResource(
                    android.R.layout.simple_spinner_dropdown_item);

            this.spUsers.setAdapter(ad);
        }
    }

}