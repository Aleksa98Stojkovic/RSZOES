package com.example.androidclient;

import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.net.Socket;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Socket socket;
    private BufferedReader br;
    private PrintWriter pw;
    private ReceiveMessageFromServer rmfs;

    // GUI elements
    Button btnRegister;
    Button btnAccept;
    Button btnDecline;
    EditText etUserName;
    EditText etIP;
    TextView tvInfo;
    Spinner spUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.btnRegister = findViewById(R.id.btnRegistruj);
        this.btnAccept = findViewById(R.id.btnPrihvati);
        this.btnDecline = findViewById(R.id.btnOdbij);
        this.etUserName = findViewById(R.id.etIme);
        this.etIP = findViewById(R.id.etIP);
        this.tvInfo = findViewById(R.id.tvInfo);
        this.spUsers = findViewById(R.id.spKorisnici);

        // Attaching functions to buttons
        this.btnRegister.setOnClickListener(v -> MainActivity.this.registerUser());
        this.btnAccept.setOnClickListener(v -> MainActivity.this.acceptGame());
        this.btnDecline.setOnClickListener(v -> MainActivity.this.declineGame());
    }

    public BufferedReader getBr()
    {
        return this.br;
    }

    private void registerUser()
    {
        try
        {
            String ip = this.etIP.getText().toString();
            String userName = this.etUserName.getText().toString();
            this.socket = new Socket(ip, 8080);
            this.br = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            this.pw = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream()), true);

            if(!(userName.equals("") || ip.equals("")))
            {
                this.rmfs = new ReceiveMessageFromServer(this);
                this.pw.println("init:" + userName);
            }


        } catch (IOException ex) {
            Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void acceptGame()
    {}

    private void declineGame()
    {}

    public void setSpinner(String[] users)
    {
        if(!users[0].equals("None")) {
            ArrayAdapter ad
                    = new ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    users);

            ad.setDropDownViewResource(
                    android.R.layout.simple_spinner_dropdown_item);

            this.spUsers.setAdapter(ad);
        }
    }

}