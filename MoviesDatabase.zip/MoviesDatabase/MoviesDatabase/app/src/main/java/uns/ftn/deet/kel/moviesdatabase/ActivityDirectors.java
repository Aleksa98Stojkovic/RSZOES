package uns.ftn.deet.kel.moviesdatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

import uns.ftn.deet.kel.moviesdatabase.sqlite.helper.DatabaseHelper;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Actor;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Director;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Movie;

public class ActivityDirectors extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    Spinner spDirectors;

    Button btnAddDirector;
    Button btnUpdateDirector;
    Button btnDeleteDirector;
    Button btnFindDirector;
    Button btnFindDirectorByMovie;
    Button btnSwitchLeft;

    EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directors);

        this.spDirectors = (Spinner) findViewById(R.id.spDirectors);

        this.btnAddDirector = (Button) findViewById(R.id.btnAddDirector);
        this.btnUpdateDirector = (Button) findViewById(R.id.btnUpdateDirector);
        this.btnDeleteDirector = (Button) findViewById(R.id.btnDeleteDirector);
        this.btnFindDirector = (Button) findViewById(R.id.btnFindDirector);
        this.btnFindDirectorByMovie = (Button) findViewById(R.id.btnSearchByMovie);
        this.etSearch = (EditText) findViewById(R.id.etSearchDirectors);
        this.btnSwitchLeft = (Button) findViewById(R.id.btnSwitchToMoviesFromDirectors);

        this.btnAddDirector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Form: Director's name @ Director's birthday
                String message = ActivityDirectors.this.etSearch.getText().toString();
                String[] data = message.split("[@]");
                Director d = new Director(data[0], data[1]);
                GlobalDataBase.getDataBaseHelper().createDirector(d);

                ActivityDirectors.this.loadSpinnerDataDirectors(GlobalDataBase.getDataBaseHelper().getAllDirectors());
            }
        });            // FINISHED
        this.btnUpdateDirector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Form: Director's name @ Director's birthday
                String directorToUpdate = ActivityDirectors.this.spDirectors.getSelectedItem().toString();
                ArrayList<Director> directors = GlobalDataBase.getDataBaseHelper().findDirectors(directorToUpdate);
                String message = ActivityDirectors.this.etSearch.getText().toString();
                String[] data = message.split("[@]");
                for(Director dir : directors)
                {
                    dir.setName(data[0]);
                    dir.setBirthDate(data[1]);
                    GlobalDataBase.getDataBaseHelper().updateDirector(dir);
                }

                ActivityDirectors.this.loadSpinnerDataDirectors(GlobalDataBase.getDataBaseHelper().getAllDirectors());
            }
        });         // FINISHED
        this.btnDeleteDirector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = ActivityDirectors.this.spDirectors.getSelectedItem().toString();
                GlobalDataBase.getDataBaseHelper().deleteDirector(message);

                ActivityDirectors.this.loadSpinnerDataDirectors(GlobalDataBase.getDataBaseHelper().getAllDirectors());
            }
        });         // FINISHED
        this.btnFindDirector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String input = ActivityDirectors.this.etSearch.getText().toString();
                loadSpinnerDataDirectors(GlobalDataBase.getDataBaseHelper().findDirectors(input));
            }
        });           // FINISHED
        this.btnFindDirectorByMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = ActivityDirectors.this.etSearch.getText().toString();
                ActivityDirectors.this.loadSpinnerDataDirectors(GlobalDataBase.getDataBaseHelper().getAllDirectorsByMovies(message));
            }
        });    // FINISHED
        this.btnSwitchLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switchActivityLeft = new Intent(ActivityDirectors.this, ActivityMovies.class);
                switchActivityLeft.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                ActivityDirectors.this.startActivity(switchActivityLeft);
            }
        });

        while(GlobalDataBase.getDataBaseHelper() == null);
        this.databaseHelper = GlobalDataBase.getDataBaseHelper();
        this.createTablesAndInitData();

    }

    void createTablesAndInitData(){
        List<Director> ld = databaseHelper.getAllDirectors();
        loadSpinnerDataDirectors((ArrayList<Director>) ld);
    }

    void loadSpinnerDataDirectors (ArrayList<Director> al){
        ArrayList<String> directornames = new ArrayList<>();
        for (Director director : al){
            directornames.add(director.getName());
        }
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, directornames);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spDirectors.setAdapter(dataAdapter);
    }
}