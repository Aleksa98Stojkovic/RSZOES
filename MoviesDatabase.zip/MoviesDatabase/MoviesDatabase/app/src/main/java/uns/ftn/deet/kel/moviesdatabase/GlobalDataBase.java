package uns.ftn.deet.kel.moviesdatabase;

import uns.ftn.deet.kel.moviesdatabase.sqlite.helper.DatabaseHelper;

public class GlobalDataBase {
    private static DatabaseHelper databaseHelper = null;

    public static synchronized DatabaseHelper getDataBaseHelper()
    {
        return databaseHelper;
    }

    public static synchronized void setDataBaseHelper(DatabaseHelper dtb)
    {
        databaseHelper = dtb;
    }

}
