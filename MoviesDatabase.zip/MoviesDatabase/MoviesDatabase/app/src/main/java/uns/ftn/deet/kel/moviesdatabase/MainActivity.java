package uns.ftn.deet.kel.moviesdatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

import uns.ftn.deet.kel.moviesdatabase.sqlite.helper.DatabaseHelper;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Actor;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Director;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Movie;

public class MainActivity extends AppCompatActivity {
    // Database Helper
    DatabaseHelper databaseHelper;

    Spinner spActors;
    Button btnAddActor;
    Button btnUpdateActor;
    Button btnDeleteActor;
    Button btnFindByMovie;
    Button btnFindActors;
    Button btnSwitchRight;

    EditText etSearch;

    // Not in use
    // Button btnDeleteDatabase;
    Button btnRestoreDatabase;

    @Override
    protected void onStop() {
        super.onStop();
        // GlobalDataBase.getDataBaseHelper().closeDB();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.spActors = (Spinner) findViewById(R.id.spActors);

        this.btnAddActor = (Button) findViewById(R.id.btnAddActor);
        this.btnUpdateActor = (Button) findViewById(R.id.btnUpdateActors);
        this.btnDeleteActor = (Button) findViewById(R.id.btnDeleteActors);
        this.btnFindActors = (Button) findViewById(R.id.btnFindActor);
        this.btnFindByMovie = (Button) findViewById(R.id.btnSearchActorByMovie);
        this.etSearch = (EditText) findViewById(R.id.etSearchActors);
        this.btnSwitchRight = (Button) findViewById(R.id.btnSwitchToMoviesFromActors);
        this.btnRestoreDatabase = (Button) findViewById(R.id.btnRestartDataBase);

        this.btnAddActor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Form: Actor's name @ Actor's birthday
                String message = MainActivity.this.etSearch.getText().toString();
                String[] data = message.split("[@]");
                Actor a = new Actor(data[0], data[1]);
                GlobalDataBase.getDataBaseHelper().createActor(a);

                MainActivity.this.loadSpinnerDataActors(GlobalDataBase.getDataBaseHelper().getAllActors());
            }
        });             // FINISHED
        this.btnUpdateActor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Form: Actor's name @ Actor's birthday
                String actorToUpdate = MainActivity.this.spActors.getSelectedItem().toString();
                ArrayList<Actor> actors = GlobalDataBase.getDataBaseHelper().findActors(actorToUpdate);
                String message = MainActivity.this.etSearch.getText().toString();
                String[] data = message.split("[@]");
                for(Actor actor : actors)
                {
                    actor.setName(data[0]);
                    actor.setBirthDate(data[1]);
                    GlobalDataBase.getDataBaseHelper().updateActor(actor);
                }

                MainActivity.this.loadSpinnerDataActors(GlobalDataBase.getDataBaseHelper().getAllActors());
            }
        });          // FINISHED
        this.btnDeleteActor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Form: Actor's name @ Actor's birthday
                String message = MainActivity.this.spActors.getSelectedItem().toString();
                GlobalDataBase.getDataBaseHelper().deleteActor(message);

                MainActivity.this.loadSpinnerDataActors(GlobalDataBase.getDataBaseHelper().getAllActors());
            }
        });          // FINISHED
        this.btnFindActors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String input = MainActivity.this.etSearch.getText().toString();
                loadSpinnerDataActors(GlobalDataBase.getDataBaseHelper().findActors(input));
            }
        });           // FINISHED
        this.btnFindByMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = MainActivity.this.etSearch.getText().toString();
                MainActivity.this.loadSpinnerDataActors(GlobalDataBase.getDataBaseHelper().getAllActorsInMovie(message));
            }
        });          // FINISHED
        this.btnSwitchRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switchActivity = new Intent(MainActivity.this, ActivityMovies.class);
                switchActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                MainActivity.this.startActivity(switchActivity);
            }
        });
        this.btnRestoreDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalDataBase.getDataBaseHelper().dropTables();
                MainActivity.this.createTablesAndInitData();
            }
        });

        databaseHelper = new DatabaseHelper(getApplicationContext());
        GlobalDataBase.setDataBaseHelper(databaseHelper);
        createTablesAndInitData();

    }

    void createTablesAndInitData(){
        GlobalDataBase.getDataBaseHelper().createTables();

        if (GlobalDataBase.getDataBaseHelper().getAllActors().size() == 0) {
            Actor a1 = new Actor("Brad Pitt", "18-12-1963");
            Actor a2 = new Actor("Edward Norton", "18-08-1969");
            Actor a3 = new Actor("Samuel L. Jackson", "21-12-1948");
            Actor a4 = new Actor("Bruce Willis", "19-03-1955");
            Actor a5 = new Actor("Leonardo DiCaprio", "11-11-1974");
            Actor a6 = new Actor("Matt Damon", "08-10-1970");
            Director d1 = new Director("Quentin Tarantino", "27-03-1963");
            Director d2 = new Director("Martin Scorsese", "17-11-1942");
            Director d3 = new Director("David Fincher", "28-08-1962");
            Director d4 = new Director("Terry Gilliam", "22-11-1940");

            GlobalDataBase.getDataBaseHelper().createActor(a1);
            GlobalDataBase.getDataBaseHelper().createActor(a2);
            GlobalDataBase.getDataBaseHelper().createActor(a3);
            GlobalDataBase.getDataBaseHelper().createActor(a4);
            GlobalDataBase.getDataBaseHelper().createActor(a5);
            GlobalDataBase.getDataBaseHelper().createActor(a6);
            GlobalDataBase.getDataBaseHelper().createDirector(d1);
            GlobalDataBase.getDataBaseHelper().createDirector(d2);
            GlobalDataBase.getDataBaseHelper().createDirector(d3);
            GlobalDataBase.getDataBaseHelper().createDirector(d4);
            Movie m1 = new Movie("Pulp fiction", "23-09-1994");
            m1.setDirector(d1);
            GlobalDataBase.getDataBaseHelper().createMovie(m1);
            m1.addActor(a4);
            m1.addActor(a3);
            GlobalDataBase.getDataBaseHelper().addActorsInMovie(m1);
            Movie m2 = new Movie("Fight club", "15-10-1999");
            m2.setDirector(d3);
            GlobalDataBase.getDataBaseHelper().createMovie(m2);
            m2.addActor(a1);
            m2.addActor(a2);
            GlobalDataBase.getDataBaseHelper().addActorsInMovie(m2);
            Movie m3 = new Movie("12 monkeys", "29-12-1995");
            m3.setDirector(d4);
            GlobalDataBase.getDataBaseHelper().createMovie(m3);
            m3.addActor(a1);
            m3.addActor(a4);
            GlobalDataBase.getDataBaseHelper().addActorsInMovie(m3);
            Movie m4 = new Movie("Django Unchained", "11-12-2012");
            m4.setDirector(d1);
            GlobalDataBase.getDataBaseHelper().createMovie(m4);
            m4.addActor(a3);
            m4.addActor(a5);
            GlobalDataBase.getDataBaseHelper().addActorsInMovie(m4);
            Movie m5 = new Movie("Shutter island", "13-02-2010");
            m5.setDirector(d2);
            GlobalDataBase.getDataBaseHelper().createMovie(m5);
            m5.addActor(a5);
            GlobalDataBase.getDataBaseHelper().addActorsInMovie(m5);
            Movie m6 = new Movie("The departed", "26-09-2006");
            m6.setDirector(d2);
            GlobalDataBase.getDataBaseHelper().createMovie(m6);
            m6.addActor(a5);
            m6.addActor(a6);
            GlobalDataBase.getDataBaseHelper().addActorsInMovie(m6);
            Movie m7 = new Movie("Once upon a time in Hollywood", "21-05-2019");
            m7.setDirector(d1);
            GlobalDataBase.getDataBaseHelper().createMovie(m7);
            m7.addActor(a1);
            m7.addActor(a5);
            GlobalDataBase.getDataBaseHelper().addActorsInMovie(m7);
        }

        List<Actor> la = GlobalDataBase.getDataBaseHelper().getAllActors();
        loadSpinnerDataActors((ArrayList<Actor>) la);

    }
    void loadSpinnerDataActors (ArrayList<Actor> al){
        ArrayList<String> actornames = new ArrayList<>();
        for (Actor actor : al){
            actornames.add(actor.getName());
        }
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, actornames);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spActors.setAdapter(dataAdapter);
    }




}