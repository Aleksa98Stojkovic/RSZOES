package uns.ftn.deet.kel.moviesdatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import uns.ftn.deet.kel.moviesdatabase.sqlite.helper.DatabaseHelper;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Actor;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Director;
import uns.ftn.deet.kel.moviesdatabase.sqlite.model.Movie;

public class ActivityMovies extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    Spinner spMovies;

    Button btnAddMovie;
    Button btnUpdateMovie;
    Button btnDeleteMovie;
    Button btnFindMovie;
    Button btnFindMovieByActor;
    Button btnFindMovieByDirector;
    Button btnSwitchRight;
    Button btnSwitchLeft;
    Button btnAddActorToMovie;
    Button btnDeleteActorFromMovie;

    EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies);

        this.spMovies = (Spinner) findViewById(R.id.spMovies);

        this.btnAddMovie = (Button) findViewById(R.id.btnAddMovie);
        this.btnUpdateMovie = (Button) findViewById(R.id.btnUpdateMovie);
        this.btnDeleteMovie = (Button) findViewById(R.id.btnDeleteMovie);
        this.btnFindMovie = (Button) findViewById(R.id.btnFindMovie);
        this.btnFindMovieByActor = (Button) findViewById(R.id.btnSearchByActor);
        this.btnFindMovieByDirector = (Button) findViewById(R.id.btnSearchByDirector);
        this.etSearch = (EditText) findViewById(R.id.etSearchMovies);
        this.btnSwitchRight = (Button) findViewById(R.id.btnSwitchToDirectors);
        this.btnSwitchLeft = (Button) findViewById(R.id.btnSwitchToActors);;
        this.btnAddActorToMovie = (Button) findViewById(R.id.btnAddActorToMovie);
        this.btnDeleteActorFromMovie = (Button) findViewById(R.id.btnDeleteActorFromMovie);

        this.btnAddMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Form: Name of the movie @ Release date @ Director's name
                String message = ActivityMovies.this.etSearch.getText().toString();
                String[] data = message.split("[@]");
                Movie m = new Movie(data[0], data[1]);

                ArrayList<Director> directors = GlobalDataBase.getDataBaseHelper().getAllDirectors();
                for(Director dir : directors)
                {
                    if(dir.getName().equals(data[2]))
                    {
                        m.setDirector(dir);
                        GlobalDataBase.getDataBaseHelper().createMovie(m);
                        break;
                    }
                }

                ActivityMovies.this.loadSpinnerDataMovies(GlobalDataBase.getDataBaseHelper().getAllMovies());

            }
        });                // FINISHED
        this.btnUpdateMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Form: Name of the movie @ Release date @ Director's name
                String movieToUpdate = ActivityMovies.this.spMovies.getSelectedItem().toString();
                ArrayList<Movie> movies = GlobalDataBase.getDataBaseHelper().findMovies(movieToUpdate);
                String message = ActivityMovies.this.etSearch.getText().toString();
                String[] data = message.split("[@]");

                for(Movie movie : movies)
                {
                    movie.setName(data[0]);
                    movie.setReleaseDate(data[1]);
                    ArrayList<Director> directors = GlobalDataBase.getDataBaseHelper().getAllDirectors();
                    for(Director dir : directors)
                    {
                        if(dir.getName().equals(data[2]))
                        {
                            movie.setDirector(dir);
                            GlobalDataBase.getDataBaseHelper().updateMovie(movie);
                            break;
                        }
                    }
                }

                ActivityMovies.this.loadSpinnerDataMovies(GlobalDataBase.getDataBaseHelper().getAllMovies());
            }
        });             // FINISHED
        this.btnDeleteMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = ActivityMovies.this.spMovies.getSelectedItem().toString();
                GlobalDataBase.getDataBaseHelper().deleteMovie(message);
                ActivityMovies.this.loadSpinnerDataMovies(GlobalDataBase.getDataBaseHelper().getAllMovies());
            }
        });             // FINISHED
        this.btnFindMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String input = ActivityMovies.this.etSearch.getText().toString();
                loadSpinnerDataMovies(GlobalDataBase.getDataBaseHelper().findMovies(input));
            }
        });               // FINISHED
        this.btnFindMovieByActor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = ActivityMovies.this.etSearch.getText().toString();
                ActivityMovies.this.loadSpinnerDataMovies(GlobalDataBase.getDataBaseHelper().getAllMoviesByActor(message));
            }
        });        // FINISHED
        this.btnFindMovieByDirector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = ActivityMovies.this.etSearch.getText().toString();
                ActivityMovies.this.loadSpinnerDataMovies(GlobalDataBase.getDataBaseHelper().getAllMoviesByDirectors(message));
            }
        });     // FINISHED
        this.btnSwitchLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switchActivityLeft = new Intent(ActivityMovies.this, MainActivity.class);
                switchActivityLeft.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                ActivityMovies.this.startActivity(switchActivityLeft);
            }
        });
        this.btnSwitchRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switchActivityRight = new Intent(ActivityMovies.this, ActivityDirectors.class);
                switchActivityRight.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                ActivityMovies.this.startActivity(switchActivityRight);
            }
        });
        this.btnAddActorToMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String movieName = spMovies.getSelectedItem().toString();
                String actorName = ActivityMovies.this.etSearch.getText().toString();
                ArrayList<Actor> actors = GlobalDataBase.getDataBaseHelper().findActors(actorName);
                ArrayList<Movie> movies = GlobalDataBase.getDataBaseHelper().findMovies(movieName);
                if(actors.size() != 0)
                {
                    for(Movie movie : movies)
                    {
                        for(Actor actor : actors)
                            movie.addActor(actor);
                        GlobalDataBase.getDataBaseHelper().addActorsInMovie(movie);
                    }
                }
            }
        });
        this.btnDeleteActorFromMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String movieName = spMovies.getSelectedItem().toString();
                String actorName = ActivityMovies.this.etSearch.getText().toString();
                ArrayList<Actor> actors = GlobalDataBase.getDataBaseHelper().findActors(actorName);
                ArrayList<Movie> movies = GlobalDataBase.getDataBaseHelper().findMovies(movieName);
                if((movies.size() != 0) && (actors.size() != 0)) {
                    for (Movie movie : movies) {
                        for(Actor actor : actors)
                            GlobalDataBase.getDataBaseHelper().deleteActorMoviePair(actor, movie);
                    }
                }
            }
        });


        while(GlobalDataBase.getDataBaseHelper() == null);
        this.databaseHelper = GlobalDataBase.getDataBaseHelper();
        this.createTablesAndInitData();

    }

    void createTablesAndInitData(){

        List<Movie> mv = databaseHelper.getAllMovies();
        loadSpinnerDataMovies((ArrayList<Movie>) mv);

    }
    void loadSpinnerDataMovies (ArrayList<Movie> al){
        ArrayList<String> movienames = new ArrayList<>();
        for (Movie movie : al){
            movienames.add(movie.getName());
        }
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, movienames);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spMovies.setAdapter(dataAdapter);
    }
}