package memoryserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.net.Socket;
import java.util.ArrayList;

public class ConnectedMemoryClient implements Runnable{
    
    private Socket socket;
    private BufferedReader br;
    private PrintWriter pw;
    private ArrayList<ConnectedMemoryClient> allClients;
    
    // Details specific for this client
    // Dugmići: registracija, prihvati, odbi
    // Tekst polje: za prihvatanje i odbijanje i za ispis ko je hteo da igra sa tobom i za ip adresu
    private String userName;
    
    public ConnectedMemoryClient(Socket socket, ArrayList<ConnectedMemoryClient> allClients) {
        this.socket = socket;
        this.allClients = allClients;
        try {
            this.br = new BufferedReader(new InputStreamReader(this.socket.getInputStream(), "UTF-8"));
            this.pw = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream()), true);
            this.userName = "";
        } catch (IOException ex) {
            Logger.getLogger(ConnectedMemoryClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String getUserName()
    {
        return this.userName;
    }
    
    public void listUsers()
    {
        String message = "Spinner:";
        for(ConnectedMemoryClient client : this.allClients)
        {
            ConnectedMemoryClient pivot = client;
            for(ConnectedMemoryClient cl : this.allClients)
            {
                if(!cl.equals(pivot))
                {
                    message += cl.getUserName() + ",";
                }
            }
            if(!message.endsWith(":"))
                message = message.substring(0, message.length() - 1);
            else
                message += "None";
            pivot.pw.println(message);
        }
    }
    
    @Override
    public void run()
    {
        while (true) 
        { 
            try
            {
                if(this.getUserName().equals(""))
                {
                    String command = this.br.readLine();
                    if(command != null)
                    {
                        if(command.startsWith("init:")) 
                        {
                            String[] subCommand = command.split(":");
                            System.out.println("Connected user: " + subCommand[1]);
                            this.userName = subCommand[1];
                            this.listUsers();
                        }
                    }
                    else 
                    {
                        break;
                    }
                }
                else
                {
                    System.out.println("Waitnig for a message...");
                    String cmd = this.br.readLine();
                }
            }
            catch(IOException ex)
            {
                System.out.println("Disconnected user: " + this.userName);
                for (ConnectedMemoryClient cl : this.allClients) {
                    if (cl.getUserName().equals(this.userName)) {
                        this.allClients.remove(cl);
                        this.listUsers();
                        return;
                    }
                }
            }
        }
    }
}
