package memoryserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.net.Socket;
import java.util.ArrayList;

public class ConnectedMemoryClient implements Runnable{
    
    // Staticki niz koji sadrzi one igrace koji su trenutno zauzeti
    static ArrayList<String> busyPlayers = new ArrayList();
    static ArrayList<String> currentGames = new ArrayList();
    
    private Socket socket;
    private BufferedReader br;
    private PrintWriter pw;
    private ArrayList<ConnectedMemoryClient> allClients;
    
    // Details specific for this client
    // Dugmići: registracija, prihvati, odbi
    // Tekst polje: za prihvatanje i odbijanje i za ispis ko je hteo da igra sa tobom i za ip adresu
    private String userName;
    
    public ConnectedMemoryClient(Socket socket, ArrayList<ConnectedMemoryClient> allClients) {
        this.socket = socket;
        this.allClients = allClients;
        try {
            this.br = new BufferedReader(new InputStreamReader(this.socket.getInputStream(), "UTF-8"));
            this.pw = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream()), true);
            this.userName = "";
        } catch (IOException ex) {
            Logger.getLogger(ConnectedMemoryClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String getUserName()
    {
        return this.userName;
    }
    
    public void listUsers()
    {
        for(ConnectedMemoryClient client : this.allClients)
        {
            String message = "Spinner:";
            ConnectedMemoryClient pivot = client;
            // Saljem update samo onima koji trenutno ne igraju
            if(!busyPlayers.contains(pivot.getUserName()))
            {
                for(ConnectedMemoryClient cl : this.allClients)
                {
                    if(!cl.equals(pivot))
                    {
                        if(!busyPlayers.contains(cl.getUserName()))
                        {
                            String msg = cl.getUserName() + ",";
                            message = message + msg;
                        }
                    }
                }
                if(!message.endsWith(":"))
                    message = message.substring(0, message.length() - 1);
                else
                    message += "None";

                pivot.pw.println(message);
            }
        }
    }
    
    public void forwardRequest(String user)
    {
        // Upisujem moje ime
        busyPlayers.add(this.userName);
        for(ConnectedMemoryClient client : this.allClients)
        {
            if(client.getUserName().equals(user))
            {
                // Format poruke je gameRequest:Korisnik:info
                client.pw.println("gameRequest:" + this.userName + " želi da igra sa Vama");
                break;
            }
        }
    }
    
    public void acceptRequest(String user)
    {   
        currentGames.add(user + "$" + this.userName);
        // Upisujem ime protivnika
        busyPlayers.add(this.userName);
        for(ConnectedMemoryClient client : this.allClients)
        {
            if(client.getUserName().equals(user))
            {
                // Format poruke je accept:Korisnik:info
                client.pw.println("acceptServer:" + this.userName + ":" + this.userName + " je prihvatio igru");
                // Potrebno je azurirati listu za sve igrace
                this.listUsers();
                break;
            }
        }
    }
    
    public void declineRequest(String user)
    {
        // Uklanjam moje ime, jer je odbijen zahtev za igrom
        busyPlayers.remove(user);
        for(ConnectedMemoryClient client : this.allClients)
        {
            if(client.getUserName().equals(user))
            {
                // Format poruke je gameRequest:Korisnik:info
                client.pw.println("declineServer:" + this.userName + " je odbio igru");
                break;
            }
        }
    }
    
    public void endOfGame(String user)
    {
        busyPlayers.remove(user);
        this.listUsers();
    }
    
    @Override
    public void run()
    {
        while (true) 
        { 
            try
            {
                if(this.getUserName().equals(""))
                {
                    String command = this.br.readLine();
                    if(command != null)
                    {
                        if(command.startsWith("init:")) 
                        {
                            String[] subCommand = command.split(":");
                            System.out.println("Connected user: " + subCommand[1]);
                            this.userName = subCommand[1];
                            this.listUsers();
                        }
                    }
                    else 
                    {
                        break;
                    }
                }
                else
                {
                    System.out.println("Waitnig for a message...");
                    String cmd = this.br.readLine();
                    System.out.println("PORUKU JE POSLAO " + this.getUserName());
                    System.out.println(cmd);
                    if(cmd.startsWith("sendRequest:"))
                    {
                        this.forwardRequest(cmd.split(":")[1]);
                    }
                    else if(cmd.startsWith("acceptClient:"))
                    {
                        this.acceptRequest(cmd.split(":")[1]);
                    }
                    else if(cmd.startsWith("declineClient:"))
                    {
                        this.declineRequest(cmd.split(":")[1]);
                    }
                    else if(cmd.startsWith("endofgame:"))
                    {
                        // instruction:user:key
                        this.endOfGame(cmd.split(":")[1]);
                    }
                    else if(cmd.startsWith("sendInitSate:"))
                    {
                        // instruction:user:cards
                        for(ConnectedMemoryClient client : this.allClients)
                        {
                            if(client.getUserName().equals(cmd.split(":")[1]))
                            {
                                System.out.println("receiveInitState:" + cmd.split(":")[2]);
                                client.pw.println("receiveInitState:" + cmd.split(":")[2]);
                                break;
                            }
                        }
                    }
                    else if(cmd.startsWith("sendCurrentState:"))
                    {
                        // instruction:user:cardsState:turn:myResult
                        for(ConnectedMemoryClient client : this.allClients)
                        {
                            if(client.getUserName().equals(cmd.split(":")[1]))
                            {
                                System.out.println("Salje se poruka korisniku " + client.getUserName());
                                client.pw.println("receiveCurrentState:" + cmd.split(":")[2] + ":" + cmd.split(":")[3] + ":" + cmd.split(":")[4]);
                                break;
                            }
                        }
                    }
                    else if(cmd.startsWith("sendTextMessage:"))
                    {
                        // instruction:user:message
                        for(ConnectedMemoryClient client : this.allClients)
                        {
                            if(client.getUserName().equals(cmd.split(":")[1]))
                            {
                                System.out.println("Salje se poruka korisniku " + client.getUserName());
                                client.pw.println("receiveTextMessage:" + cmd.split(":")[2]);
                                break;
                            }
                        }
                    }
                    else if(cmd.startsWith("sendEndActivity:"))
                    {
                        // instruction:user:key
                        System.out.println("");
                        System.out.println("Broj elemenata Hash Map-e PRE brisanja je: " + currentGames.size());
                        currentGames.remove(cmd.split(":")[2]);
                        System.out.println("Broj elemenata Hash Map-e POSLE brisanja je: " + currentGames.size());
                        System.out.println("");
                        for(ConnectedMemoryClient client : this.allClients)
                        {
                            if(client.getUserName().equals(cmd.split(":")[1]))
                            {
                                System.out.println("Salje se poruka korisniku " + client.getUserName());
                                client.pw.println("receiveEndActivity:");
                                break;
                            }
                        }
                    }
                    else
                        System.out.println("Unknown command");
                }
            }
            catch(IOException ex)
            {
                System.out.println("Disconnected user: " + this.userName);
                for (ConnectedMemoryClient cl : this.allClients) {
                    if (cl.getUserName().equals(this.userName)) {
                        this.allClients.remove(cl);
                        this.listUsers();
                        return;
                    }
                }
            }
        }
    }
}
