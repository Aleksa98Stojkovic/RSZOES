package com.example.dynamicimageview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    int numRows = 6;
    int numColumns = 5;
    HashMap<String, ImageView> images;
    EditText etImgCol;
    EditText etImgRow;
    Button btnChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etImgCol = findViewById(R.id.etImgCol);
        etImgRow = findViewById(R.id.etImgRow);
        btnChange = findViewById(R.id.button);
        images = new HashMap<>();
        LinearLayout llmain = findViewById(R.id.lvmain);
        for (int row = 1; row <= numRows; row++){
            LinearLayout llrow = new LinearLayout(this);
            llrow.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 1; col <= numColumns; col++){
                ImageView iv = new ImageView(this);
                iv.setTag(row+","+col);
                images.put(row+","+col, iv);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0,200);
                layoutParams.weight = 1;
                iv.setLayoutParams(layoutParams);
                iv.setImageResource(R.drawable.flower);
                iv.setOnClickListener((v)->{
                    Toast.makeText(MainActivity.this, "Kliknuo si na sliku "+v.getTag().toString(), Toast.LENGTH_SHORT).show();
                });
                llrow.addView(iv);
            }
            llmain.addView(llrow);
        }
        btnChange.setOnClickListener((v)->{
            String row = etImgRow.getText().toString();
            String col = etImgCol.getText().toString();
            String key = row+","+col;
            if (Integer.parseInt(row) <= numRows && Integer.parseInt(col) <= numColumns){
                images.get(key).setImageResource(R.drawable.replacement);
            }
            else{
                Toast.makeText(MainActivity.this, "Invalid row/column number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}